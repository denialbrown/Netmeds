const express = require('express');
const router = express.Router();
const productController = require("../controller/productCantroller");
const middleware = require("../helper/middleware")

router.post("/add/category", [middleware.authenticateUser],
    productController.addCategory);
router.post("/add/sub-category", [middleware.authenticateUser],
    productController.addSubCategory);


router.post("/add/product", [middleware.authenticateUser],productController.addProduct);

router.get("/get/product", [middleware.authenticateUser], productController.listProduct);

router.get("/get/product/:productId", [middleware.authenticateUser], productController.getproduct);

router.post("/update/product/:productId", [middleware.authenticateUser], productController.updateProduct);

router.delete("/delete/product/:productId", [middleware.authenticateUser], productController.deleteProduct);

module.exports = router