const categorySchema = require("../models/category");
const subCategorySchema = require("../models/subCategory");
const productSchema = require("../models/product");
const Service = require("../helper/index");
const send = Service.sendResponse;
const { ErrorCode, HttpStatus } = require("../helper/enum")
const { Message } = require("../helper/localization");
const { query } = require("express");
const fs = require('fs');
const { log } = require("console");
const path = require("path");

module.exports = {

    addCategory: async function (req, res) {
        try {
            var category = new categorySchema;
            category.categoryName = req.body.categoryName
            category.userId = req.authUser._id
            category.save()
            return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.CATEGORY_ADDED, {
                categoryName: category.categoryName
            });
        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
    addSubCategory: async function (req, res) {
        try {
            console.log(req.body);
            var category = new subCategorySchema;
            category.subCategoryName = req.body.subCategoryName
            category.userId = req.authUser._id
            category.save()
            return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.CATEGORY_ADDED, {
                subCategoryName: category.subCategoryName
            });
        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
    addProduct: async function (req, res) {
        try {
            console.log(req.body);
            var newproduct = new productSchema;
            newproduct.categoryId = req.body.categoryId
            newproduct.subCategoryId = req.body.subCategoryId
            newproduct.userId = req.authUser._id
            newproduct.productName = req.body.productName
            newproduct.details = req.body.details
            newproduct.price = req.body.price
            newproduct.pricedetails = req.body.pricedetails
            // await newproduct.save()
            // return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_ADD_SUCCESS, {
            //     categoryId: newproduct.categoryId,
            //     subCategoryId: newproduct.subCategoryId,
            //     productName: newproduct.productName,
            //     details: newproduct.details,
            //     price: newproduct.price,
            //     pricedetails: newproduct.pricedetails,
            // });
            console.log(newproduct._id);
            if (!req.files) {
                return send(res, HttpStatus.BAD_REQUEST_STATUS_CODE, ErrorCode.REQUIRED_CODE, Message.IMAGE_REQUIRED, null);
            }
            const folderName = newproduct._id.valueOf()
            fs.mkdir('./uploads/' + folderName, (err) => {
                if (err) {
                    console.log(err);
                }
            })
            const files = req.files.images
            console.log(files);
            for (let i = 0; i < files.length; i++) {
                let fileNames = files[i].name;
                console.log(fileNames);
                const extention = path.extname(fileNames).slice(1)
                var time = Service.getCurrentTimeStampUnix()
                var newFileName = folderName + '-' + time + '.' + extention
                console.log(newFileName);
                files[i].mv ('./uploads/' + folderName + '/' + newFileName, (err) => {
                    if (err) {
                        console.log(err);
                    }
                    console.log("file is uploaded");
                })
                var images = new productSchema;
            
            }

            // var  fileName= []
            // files.forEach(async (value) => {
            //     var data = {
            //         fileName:value.name
            //     }
            //     fileName.push(data)
            // })
            // console.log(fileName);
        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
    listProduct: async function (req, res) {
        try {
            const filter = {
                userId: req.authUser._id,
                isDeleted: false,
            }
            var product = await productSchema.aggregate([
                {
                    $match: filter,
                },
                {
                    $lookup: {
                        from: "categories",
                        localField: "categoryId",
                        foreignField: "_id",
                        as: "categoryName",
                    },
                },
                {
                    $lookup: {
                        from: "subcategories",
                        localField: "subCategoryId",
                        foreignField: "_id",
                        as: "subCategoryName",
                    },
                },
                {
                    $project: {
                        _id: 0,
                        categoryName: {
                            $arrayElemAt: ["$categoryName.categoryName", 0]
                        },
                        subCategoryName: {
                            $arrayElemAt: ["$subCategoryName.subCategoryName", 0]
                        },
                        productName: 1,
                        details: 1,
                        price: 1,
                        pricedetails: 1,
                    },
                },
            ])
                .exec();
            return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_LIST, product);
        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
    getproduct: async function (req, res) {
        try {
            let product = await productSchema.find({ _id: req.params.productId, isDeleted: false })
                .populate('categoryId')
                .populate('subCategoryId')
                .exec()
            var mainProduct = []
            product.forEach(async (value) => {
                var data = {
                    categoryName: value.categoryId.categoryName,
                    subCategoryName: value.subCategoryId.subCategoryName,
                    productName: value.productName,
                    details: value.details,
                    price: value.price,
                    pricedetails: value.pricedetails,
                }
                mainProduct.push(data)
            })
            return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_LIST, mainProduct);

        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
    updateProduct: async function (req, res) {
        try {
            var checkProduct = await productSchema.findOne({ _id: req.params.productId, isDeleted: false });
            if (!checkProduct) {
                return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_NOT_FOUND, null);
            }
            checkProduct.categoryId = req.body.categoryId
            checkProduct.subCategoryId = req.body.subCategoryId
            checkProduct.productName = req.body.productName
            checkProduct.details = req.body.details
            checkProduct.price = req.body.price
            checkProduct.pricedetails = req.body.pricedetails
            await checkProduct.save()
            return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_UPDATE_SUCCESS, {
                categoryName: checkProduct.categoryId,
                subCategoryName: checkProduct.subCategoryId,
                productName: checkProduct.productName,
                details: checkProduct.details,
                price: checkProduct.price,
                pricedetails: checkProduct.pricedetails,
            });
        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
    deleteProduct: async function (req, res) {
        try {
            var checkProduct = await productSchema.findOne({ _id: req.params.productId, isDeleted: false });
            if (!checkProduct) {
                return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_NOT_FOUND, null);
            }
            checkProduct.isDeleted = true;
            checkProduct.save()
            return send(res, HttpStatus.SUCCESS_CODE, HttpStatus.SUCCESS_CODE, Message.PRODUCT_DELETE, null);
        } catch (error) {
            console.log('error', error);
            return send(res, HttpStatus.INTERNAL_SERVER_CODE, HttpStatus.INTERNAL_SERVER_CODE, Message.SOMETHING_WENT_WRONG, null);
        }
    },
}